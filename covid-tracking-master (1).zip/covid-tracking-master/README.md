# covid-tracking
To track the citizens and identifing covid potential people
